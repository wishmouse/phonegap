


var app = {
    // Application Constructor
    initialize: function() {
      this.bindEvents();
    },

    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
        window.addEventListener('batterystatus', onBatteryStatus, false);
    },

    onDeviceReady: function() {
        app.receivedEvent('deviceready');
        // window.addEventListener('batterystatus', onBatteryStatus, false);

        // var element = document.getElementById('deviceProperties');
        //
        // element.innerHTML = 'Device Model: '+ device.model    + '<br />' +
        //                 'Device Cordova: '  + device.cordova  + '<br />' +
        //                 'Device Platform: ' + device.platform + '<br />' +
        //                 'Device UUID: '     + device.uuid     + '<br />' +
        //                 'Device Version: '  + device.version  + '<br />';
    },

    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');
        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');


        console.log('Received Event: ' + id);
    }

};


function onBatteryStatus(status) {
  $('#battery').html("Level: " + status.level + " isPlugged: " + status.isPlugged)

  console.log("Level: " + status.level + " isPlugged: " + status.isPlugged);
}
